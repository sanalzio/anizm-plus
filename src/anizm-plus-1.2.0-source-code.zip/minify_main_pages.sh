minify arama.html > ./build/arama.html
minify options.html > ./build/options.html
minify popup.html > ./build/popup.html
