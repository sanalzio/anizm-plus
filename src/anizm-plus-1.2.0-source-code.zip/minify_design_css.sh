minify ./styles/design/chat_window.css > ./build/styles/design/chat_window.css
minify ./styles/design/chatango.css > ./build/styles/design/chatango.css
minify ./styles/design/for_color_themes.css > ./build/styles/design/for_color_themes.css
minify ./styles/design/min_theme.css > ./build/styles/design/min_theme.css
minify ./styles/design/necessary.css > ./build/styles/design/necessary.css
minify ./styles/design/remove_bgs.css > ./build/styles/design/remove_bgs.css
